/* This file auto-generated from standard.mac by genmacro.c - don't edit it */

#include <stddef.h>

static const char *nasm_version_mac[] = {
    "%define __YASM_MAJOR__ 1",
    "%define __YASM_MINOR__ 3",
    "%define __YASM_SUBMINOR__ 0",
    "%define __YASM_BUILD__ 0",
    "%define __YASM_PATCHLEVEL__ 0",
    "%define __YASM_VERSION_ID__ 001030000h",
    "%define __YASM_VER__ \"1.3.0\"",
    NULL
};
