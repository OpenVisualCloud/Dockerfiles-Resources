# FFmpeg patches

* VAAPI

* Media Analytics

* Thirdparty
