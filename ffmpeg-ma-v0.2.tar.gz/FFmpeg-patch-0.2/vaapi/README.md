# VAAPI based patches
