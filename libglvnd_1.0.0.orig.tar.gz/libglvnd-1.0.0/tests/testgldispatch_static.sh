#!/bin/bash

./testgldispatch -s

