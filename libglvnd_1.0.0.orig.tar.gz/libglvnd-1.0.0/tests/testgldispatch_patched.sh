#!/bin/bash

./testgldispatch -s -g -p

