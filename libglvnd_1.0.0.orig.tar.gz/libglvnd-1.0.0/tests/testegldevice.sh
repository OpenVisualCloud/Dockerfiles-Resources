#!/bin/bash

source $TOP_SRCDIR/tests/eglenv.sh

./testegldevice
