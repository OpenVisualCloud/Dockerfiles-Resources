#!/bin/bash

./testgldispatch -g

