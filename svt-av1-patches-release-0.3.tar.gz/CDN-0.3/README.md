# Patches for CDN-Transcode-Sample
