# Client side certificate management

We recommand to use default credential storage to verify and manage certificates on different platforms.
Windows: (https://docs.microsoft.com/en-us/windows-hardware/drivers/install/certificate-stores)
IOS: (https://developer.apple.com/documentation/security/certificate_key_and_trust_services/certificates)
Android: (https://developer.android.com/training/articles/security-config)
