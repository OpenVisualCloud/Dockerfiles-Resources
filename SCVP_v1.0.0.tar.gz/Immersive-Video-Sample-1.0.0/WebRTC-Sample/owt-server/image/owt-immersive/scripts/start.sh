#!/bin/bash -e

cd /home/owt

./bin/start-all.sh
