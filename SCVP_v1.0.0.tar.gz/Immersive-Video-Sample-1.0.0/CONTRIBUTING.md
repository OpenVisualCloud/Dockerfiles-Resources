We welcome community contributions to the Immersive Video Sample. Thank you for your time! By contributing to the project, you agree to the license and copyright terms therein and to the release of your contribution under these terms.

## Contribution process
-  Validate that your changes do not break a build
-  Perform smoke tests and ensure they pass
-  Submit a pull request for review to the maintainer
