Use RTP Play tool with command 'rtpplay.exe -v -T -f <path>\<file.rtp> 127.0.0.1/1236' 
Example: rtpplay.exe -v -T -f hrtf_g722_1C_48.rtp 127.0.0.1/1236.  
This sends the stereo rtp file to port 1236.  
You can hear the voice getting panned from left, right and center.   
