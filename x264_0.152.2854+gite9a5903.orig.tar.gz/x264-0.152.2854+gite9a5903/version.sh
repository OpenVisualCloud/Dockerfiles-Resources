#!/bin/sh
# Script modified from upstream source for Debian packaging since packaging
# won't include .git repository.
echo '#define X264_VERSION " r2854 e9a5903"'
echo '#define X264_POINTVER "0.152.2854 e9a5903"'
