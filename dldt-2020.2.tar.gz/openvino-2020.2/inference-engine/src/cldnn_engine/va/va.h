// Copyright (C) 2018-2020 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

typedef cl_uint VASurfaceID;
typedef void* VADisplay;