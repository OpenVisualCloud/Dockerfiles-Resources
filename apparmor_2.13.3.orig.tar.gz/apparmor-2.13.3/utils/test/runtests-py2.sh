#!/bin/sh

RUNTESTS_PY__PYTHON_BINARY=python2
. ./runtests-py3.sh

