// Copyright (C) <2017> Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0

'use strict';

mocha.checkLeaks();
mocha.globals(['jQuery']);
mocha.run();
