// Copyright (C) <2019> Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0

#include "AudioRankerWrapper.h"
#include <nan.h>

using namespace v8;

NODE_MODULE(addon, AudioRanker::Init)
