/**
 * @file vp8.h Private VP8 Interface
 *
 * Copyright (C) 2010 Creytiv.com
 */

struct vp8_vidcodec {
	struct vidcodec vc;
	uint32_t max_fs;
};
