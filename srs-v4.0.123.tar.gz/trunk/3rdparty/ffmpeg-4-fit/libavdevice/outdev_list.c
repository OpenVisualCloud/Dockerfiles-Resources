static const AVOutputFormat * const outdev_list[] = {
    NULL };
