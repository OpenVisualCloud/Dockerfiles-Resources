static const AVInputFormat * const indev_list[] = {
    NULL };
