static const AVOutputFormat * const muxer_list[] = {
    NULL };
