#ifndef shine_BITSTREAM_H
#define shine_BITSTREAM_H

void shine_format_bitstream(shine_global_config *config);

#endif
