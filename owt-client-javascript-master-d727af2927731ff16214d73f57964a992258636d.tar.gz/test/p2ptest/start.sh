#!/bin/bash

cd $(dirname $0)
python start.py --browsers $1