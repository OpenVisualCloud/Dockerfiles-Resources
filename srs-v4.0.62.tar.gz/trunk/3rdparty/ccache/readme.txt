ccache是samba组织提供的加速编译过程的工具，
使用虚拟机编译可以考虑用这个工具，让编译过程飞快。

链接：
    http://ccache.samba.org/
    http://samba.org/ftp/ccache/ccache-3.1.9.tar.xz
    http://ccache.samba.org/manual.html

安装方法：
    bash build_ccache.sh
注意：要求以sudoer执行，要修改文件。