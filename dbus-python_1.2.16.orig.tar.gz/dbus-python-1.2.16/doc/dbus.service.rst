dbus.service module
-------------------

.. automodule:: dbus.service
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
