# GStreamer OpenGL Library - X11

This library should be linked to by getting cflags and libs from
`gstreamer-gl-x11-{{ gst_api_version.md }}.pc`.
