# RTP Library

This library should be linked to by getting cflags and libs from
`gstreamer-plugins-base-{{ gst_api_version.md }}.pc` and adding
`-lgstrtp-{{ gst_api_version.md }}` to the library flags.
