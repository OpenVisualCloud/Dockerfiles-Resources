# GStreamer OpenGL Library - EGL

This library should be linked to by getting cflags and libs from
`gstreamer-gl-egl-{{ gst_api_version.md }}.pc`.
