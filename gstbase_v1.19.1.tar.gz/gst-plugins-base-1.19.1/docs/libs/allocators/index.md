# Allocators Library

This library should be linked to by getting cflags and libs from
gstreamer-plugins-base-{{ gst_api_version.md }}.pc and adding
-lgstallocators-{{ gst_api_version.md }} to the library flags.
