---
short-description:  GStreamer Base Plugins API reference.
...

# GStreamer Base Plugins

