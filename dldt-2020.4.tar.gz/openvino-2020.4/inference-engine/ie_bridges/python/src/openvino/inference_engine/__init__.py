from .ie_api import *
__all__ = ['IENetwork', "TensorDesc", "IECore", "Blob", "get_version"]
__version__ = get_version()

