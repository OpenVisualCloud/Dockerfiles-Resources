package org.intel.openvino;

public class Data extends IEWrapper {

    protected Data(long addr) {
        super(addr);
    }
}
