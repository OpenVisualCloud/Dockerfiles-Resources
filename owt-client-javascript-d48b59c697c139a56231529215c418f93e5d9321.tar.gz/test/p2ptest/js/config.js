var serverIP = "place_holder";
var userName1 = "User1";
var userName2 = "User2";
var userNameInChinese = "用户1";
var userNameInSymol = "111&222@!;||(){}[]?"
var sendMsg = "nihao";
var waitInterval = 10000;
