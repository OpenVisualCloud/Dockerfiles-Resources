/*******************************************************************************
* Copyright 2002-2020 Intel Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

#include <crypto_mb/status.h>

#include <internal/common/ifma_defs.h>
#include <internal/common/ifma_cvt52.h>
#include <internal/ecnist/ifma_ecpoint_p384.h>
#include <internal/rsa/ifma_rsa_arith.h>

#ifndef BN_OPENSSL_DISABLE
#include <openssl/bn.h>
#endif


/*
// common functions
*/

/*
// compute secret key inversion
//
// inv_skey 1/skey mod n384
//
// note: pay attention on skey[] presenttaion
//       it should be FE element of N384 basef GF
*/
static void nistp384_ecdsa_inv_keys_mb8(U64 inv_skey[],
                                  const U64 skey[],
                                      int8u* pBuffer)
{
   /* compute inversion ober n384 of secret keys */
   MB_FUNC_NAME(ifma_tomont52_n384_)(inv_skey, skey);
   ifma_aminv52_n384_mb8(inv_skey, inv_skey);              /* 1/skeys mod n384 */
   MB_FUNC_NAME(ifma_frommont52_n384_)(inv_skey, inv_skey);
}

/*
// compute r-component of the ECDSA signature
//
// r = ([skey]*G).x mod n384
//
// note: pay attention on skey[] presenttaion
//       it should be transposed and zero expanded 
*/
static __mb_mask nistp384_ecdsa_sign_r_mb8(U64 sign_r[],
                                     const U64 skey[],
                                         int8u* pBuffer)
{
   /* compute ephemeral public keys */
   P384_POINT P;

   MB_FUNC_NAME(ifma_ec_nistp384_mul_pointbase_)(&P, skey);

   /* extract affine P.x */
   MB_FUNC_NAME(ifma_aminv52_p384_)(P.Z, P.Z); /* 1/Z   */
   MB_FUNC_NAME(ifma_ams52_p384_)(P.Z, P.Z);   /* 1/Z^2 */
   MB_FUNC_NAME(ifma_amm52_p384_)(P.X, P.X, P.Z);  /* x = (X) * (1/Z^2) */

   /* convert x-coordinate to regular and then tp Montgomery n384 */
   MB_FUNC_NAME(ifma_frommont52_p384_)(P.X, P.X);
   MB_FUNC_NAME(ifma_fastred52_pn384_)(sign_r, P.X);  /* fast reduction p => n */

   return MB_FUNC_NAME(is_zero_FE384_)(sign_r);
}

/*
// compute s-component of the ECDSA signature
//
// s = (inv_eph) * (msg + prv_skey*sign_r) mod n384
*/
static __mb_mask nistp384_ecdsa_sign_s_mb8(U64 sign_s[],
                                   const int8u* const pa_msg[8],
                                   const   U64 sign_r[],
                                           U64 inv_eph_skey[],
                                           U64 reg_skey[],
                                           int8u* pBuffer)
{
   __ALIGN64 U64 msg[P384_LEN52];
   __ALIGN64 U64 tmp[P384_LEN52];

   /* convert msg to mb format */
   ifma_HexStr8_to_mb8((int64u (*)[8])msg, pa_msg, P384_BITSIZE);

   /* conver to Montgomery over n384 domain */
   MB_FUNC_NAME(ifma_tomont52_n384_)(inv_eph_skey, inv_eph_skey);
   MB_FUNC_NAME(ifma_tomont52_n384_)(tmp, sign_r);
   MB_FUNC_NAME(ifma_tomont52_n384_)(msg, msg);
   MB_FUNC_NAME(ifma_tomont52_n384_)(reg_skey, reg_skey);

   /* s = (inv_eph) * (msg + prv_skey*sign_r) mod n384 */
   MB_FUNC_NAME(ifma_amm52_n384_)(sign_s, reg_skey, tmp);
   MB_FUNC_NAME(ifma_add52_n384_)(sign_s, sign_s, msg);
   MB_FUNC_NAME(ifma_amm52_n384_)(sign_s, sign_s, inv_eph_skey);
   MB_FUNC_NAME(ifma_frommont52_n384_)(sign_s, sign_s);

   return MB_FUNC_NAME(is_zero_FE384_)(sign_s);
}

/*
// ECDSA kernels
*/

/*
// pre-computation of ECDSA signature
//
// pa_inv_eph_skey[] array of pointers to the inversion of signer's ephemeral private keys
// pa_sign_rp[]      array of pointers to the r-components of the signatures 
// pa_eph_skey[]     array of pointers to the ephemeral signer's ephemeral private keys
// pBuffer           pointer to the scratch buffer
//
// function computes important value does not depending from the messages are being siggned:
// inversion of signer's ephemeral keys
// r-component of the signature
*/
DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_setup_mb8(int64u* pa_inv_eph_skey[8],
                                             int64u* pa_sign_rp[8],
                                       const int64u* const pa_skey[8],
                                              int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_inv_eph_skey || NULL==pa_sign_rp ||  NULL==pa_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }

   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      int64u* pinv_key = pa_inv_eph_skey[buf_no];
      int64u* psign_rp = pa_sign_rp[buf_no];
      const int64u* pkey = pa_skey[buf_no];
      /* if any of pointer NULL set error status */
      if(NULL==pinv_key || NULL==psign_rp || NULL==pkey) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }
   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   /* convert keys into FE and compute inversion */
   U64 T[P384_LEN52];
   ifma_BNU_to_mb8((int64u (*)[8])T, pa_skey, P384_BITSIZE);
   nistp384_ecdsa_inv_keys_mb8(T, T, 0);
   /* return results in suitable format */
   ifma_mb8_to_BNU(pa_inv_eph_skey, (const int64u(*)[8])T, P384_BITSIZE);

   /* clear key's inversion */
   MB_FUNC_NAME(zero_)((int64u (*)[8])T, sizeof(T)/sizeof(U64));

   /* convert keys into scalars */
   U64 scalarz[P384_LEN64+1];
   ifma_BNU_transpose_copy((int64u (*)[8])scalarz, pa_skey, P384_BITSIZE);
   scalarz[P384_LEN64] = get_zero64();
   /* compute r-component of the DSA signature */
   int8u stt_mask = nistp384_ecdsa_sign_r_mb8(T, scalarz, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[8])scalarz, sizeof(scalarz)/sizeof(U64));

   /* return results in suitable format */
   ifma_mb8_to_BNU(pa_sign_rp, (const int64u(*)[8])T, P384_BITSIZE);

   status |= MBX_SET_STS_BY_MASK(status, stt_mask, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

/*
// computes ECDSA signature
//
// pa_sign_r[]       array of pointers to the r-components of the signatures 
// pa_sign_s[]       array of pointers to the s-components of the signatures 
// pa_msg[]          array of pointers to the messages are being signed
// pa_sign_rp[]      array of pointers to the pre-computed r-components of the signatures 
// pa_inv_eph_skey[] array of pointers to the inversion of signer's ephemeral private keys
// pa_reg_skey[]     array of pointers to the regular signer's ephemeral private keys
// pBuffer           pointer to the scratch buffer
*/
DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_complete_mb8(int8u* pa_sign_r[8],
                                                int8u* pa_sign_s[8],
                                          const int8u* const pa_msg[8],
                                         const int64u* const pa_sign_rp[8],
                                         const int64u* const pa_inv_eph_skey[8],
                                         const int64u* const pa_reg_skey[8],
                                                int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_sign_r || NULL==pa_sign_s || NULL==pa_msg || 
      NULL==pa_sign_rp || NULL==pa_inv_eph_skey || NULL==pa_reg_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }

   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      int8u* psign_r = pa_sign_r[buf_no];
      int8u* psign_s = pa_sign_s[buf_no];
      const int8u* pmsg = pa_msg[buf_no];
      const int64u* psign_pr = pa_sign_rp[buf_no];
      const int64u* pinv_eph_key = pa_inv_eph_skey[buf_no];
      const int64u* preg_key = pa_reg_skey[buf_no];
      /* if any of pointer NULL set error status */
      if(NULL==psign_r || NULL==psign_s || NULL==pmsg ||
         NULL==psign_pr || NULL==pinv_eph_key || NULL==preg_key) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }

   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   __ALIGN64 U64 inv_eph[P384_LEN52];
   __ALIGN64 U64 reg_skey[P384_LEN52];
   __ALIGN64 U64 sign_r[P384_LEN52];
   __ALIGN64 U64 sign_s[P384_LEN52];

   /* convert inv_eph, reg_skey and sign_r to mb format */
   ifma_BNU_to_mb8((int64u (*)[8])inv_eph, pa_inv_eph_skey, P384_BITSIZE);
   ifma_BNU_to_mb8((int64u (*)[8])reg_skey, pa_reg_skey, P384_BITSIZE);
   ifma_BNU_to_mb8((int64u (*)[8])sign_r, pa_sign_rp, P384_BITSIZE);

   /* compute s- signature component: s = (inv_eph) * (msg + prv_skey*sign_r) mod n384 */
   nistp384_ecdsa_sign_s_mb8(sign_s, pa_msg, sign_r, inv_eph, reg_skey, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[8])inv_eph, sizeof(inv_eph)/sizeof(U64));
   /* clear copy of the regular secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[8])reg_skey, sizeof(reg_skey)/sizeof(U64));

   /* check if sign_r!=0 and sign_s!=0 */
   int8u stt_mask_r = MB_FUNC_NAME(is_zero_FE384_)(sign_r);
   int8u stt_mask_s = MB_FUNC_NAME(is_zero_FE384_)(sign_s);

   /* convert sign_r and sing_s to strings */
   ifma_mb8_to_HexStr8(pa_sign_r, (const int64u(*)[8])sign_r, P384_BITSIZE);
   ifma_mb8_to_HexStr8(pa_sign_s, (const int64u(*)[8])sign_s, P384_BITSIZE);

   status |= MBX_SET_STS_BY_MASK(status, stt_mask_r, MBX_STATUS_LOW_ORDER_ERR);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_s, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

/*
// Computes ECDSA signature
// pa_sign_r[]       array of pointers to the computed r-components of the signatures
// pa_sign_s[]       array of pointers to the computed s-components of the signatures
// pa_msg[]          array of pointers to the messages are being signed
// pa_eph_skey[]     array of pointers to the signer's ephemeral private keys
// pa_reg_skey[]     array of pointers to the signer's regular private keys
// pBuffer           pointer to the scratch buffer*/
DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_mb8(int8u* pa_sign_r[8],
                                       int8u* pa_sign_s[8],
                                 const int8u* const pa_msg[8],
                                const int64u* const pa_eph_skey[8],
                                const int64u* const pa_reg_skey[8],
                                       int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_sign_r || NULL==pa_sign_s || NULL==pa_msg || NULL==pa_eph_skey || NULL==pa_reg_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }
   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      int8u* psign_r = pa_sign_r[buf_no];
      int8u* psign_s = pa_sign_s[buf_no];
      const int8u* pmsg = pa_msg[buf_no];
      const int64u* peph_key = pa_eph_skey[buf_no];
      const int64u* preg_key = pa_reg_skey[buf_no];
      /* if any of pointer NULL set error status */
      if(NULL==psign_r || NULL==psign_s || NULL==pmsg || NULL==peph_key || NULL==preg_key) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }
   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   __ALIGN64 U64 inv_eph_key[P384_LEN52];
   __ALIGN64 U64 reg_key[P384_LEN52];
   __ALIGN64 U64 sign_r[P384_LEN52];
   __ALIGN64 U64 sign_s[P384_LEN52];
   __ALIGN64 U64 scalar[P384_LEN64+1];

   /* convert ephemeral keys into FE and compute inversion */
   ifma_BNU_to_mb8((int64u (*)[8])inv_eph_key, pa_eph_skey, P384_BITSIZE);
   nistp384_ecdsa_inv_keys_mb8(inv_eph_key, inv_eph_key, pBuffer);

   /* convert epphemeral keys into sclar and compute sign_r */
   ifma_BNU_transpose_copy((int64u (*)[8])scalar, pa_eph_skey, P384_BITSIZE);
   scalar[P384_LEN64] = get_zero64();
   nistp384_ecdsa_sign_r_mb8(sign_r, scalar, pBuffer);

   /* convert reg_skey and compute s-component */
   ifma_BNU_to_mb8((int64u (*)[8])reg_key, pa_reg_skey, P384_BITSIZE);
   nistp384_ecdsa_sign_s_mb8(sign_s, pa_msg, sign_r, inv_eph_key, reg_key, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[8])inv_eph_key, sizeof(inv_eph_key)/sizeof(U64));
   MB_FUNC_NAME(zero_)((int64u (*)[8])scalar, sizeof(scalar)/sizeof(U64));

   /* clear copy of the regular secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[8])reg_key, sizeof(reg_key)/sizeof(U64));

   /* check if sign_r!=0 and sign_s!=0 */
   int8u stt_mask_r = MB_FUNC_NAME(is_zero_FE384_)(sign_r);
   int8u stt_mask_s = MB_FUNC_NAME(is_zero_FE384_)(sign_s);

   /* convert singnature components to strings */
   ifma_mb8_to_HexStr8(pa_sign_r, (const int64u(*)[8])sign_r, P384_BITSIZE);
   ifma_mb8_to_HexStr8(pa_sign_s, (const int64u(*)[8])sign_s, P384_BITSIZE);

   status |= MBX_SET_STS_BY_MASK(status, stt_mask_r, MBX_STATUS_LOW_ORDER_ERR);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_s, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

/*
// OpenSSL's specific implementations
*/
#ifndef BN_OPENSSL_DISABLE

static void reverse_inplace(int8u* inpout, int len)
{
   int mudpoint = len/2;
   for(int n=0; n<mudpoint; n++) {
      int x = inpout[n];
      inpout[n] = inpout[len-1-n];
      inpout[len-1-n] = x;;
   }
}

static BIGNUM* BN_bnu2bn(int64u *val, int len, BIGNUM *ret)
{
   len = len*sizeof(int64u);
   reverse_inplace((int8u*)val, len);
   ret = BN_bin2bn((int8u*)val, len, ret);
   reverse_inplace((int8u*)val, len);
   return ret;
}

static void ifma_mb8_to_BN_384(BIGNUM* out_bn[8], const int64u inp_mb8[][8])
{
   int64u tmp[8][P384_LEN64];
   int64u* pa_tmp[8] = {tmp[0], tmp[1], tmp[2], tmp[3],
                        tmp[4], tmp[5], tmp[6], tmp[7]};
   /* convert to plain data */
   ifma_mb8_to_BNU(pa_tmp, (const int64u(*)[8])inp_mb8, P384_BITSIZE);

   for(int nb=0; nb<8; nb++)
      out_bn[nb] = BN_bnu2bn(tmp[nb], P384_LEN64, out_bn[nb]);
}

DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_setup_ssl_mb8(BIGNUM* pa_inv_skey[8],
                                                 BIGNUM* pa_sign_rp[8],
                                           const BIGNUM* const pa_skey[8],
                                                  int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_inv_skey || NULL==pa_sign_rp ||  NULL==pa_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }

   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      const BIGNUM* pkey = pa_skey[buf_no];
      /* if any of pointer NULL set error status */
      if(NULL==pkey) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }
   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   /* convert keys into FE and compute inversion */
   U64 T[P384_LEN52];
   ifma_BN_to_mb8((int64u (*)[])T, pa_skey, P384_BITSIZE);
   nistp384_ecdsa_inv_keys_mb8(T, T, 0);
   /* store results in suitable format */
   ifma_mb8_to_BN_384(pa_inv_skey, (const int64u (*)[])T);

   /* clear key's inversion */
   MB_FUNC_NAME(zero_)((int64u (*)[])T, sizeof(T)/sizeof(U64));

   /* convert keys into scalars */
   U64 scalarz[P384_LEN64+1];
   ifma_BN_transpose_copy((int64u (*)[])scalarz, pa_skey, P384_BITSIZE);
   scalarz[P384_LEN64] = get_zero64();
   /* compute r-component of the DSA signature */
   int8u stt_mask = nistp384_ecdsa_sign_r_mb8(T, scalarz, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[])scalarz, sizeof(scalarz)/sizeof(U64));

   /* store results in suitable format */
   ifma_mb8_to_BN_384(pa_sign_rp, (const int64u (*)[])T);
   
   status |= MBX_SET_STS_BY_MASK(status, stt_mask, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_complete_ssl_mb8(int8u* pa_sign_r[8],
                                                    int8u* pa_sign_s[8],
                                              const int8u* const pa_msg[8],
                                             const BIGNUM* const pa_sign_rp[8],
                                             const BIGNUM* const pa_inv_eph_skey[8],
                                             const BIGNUM* const pa_reg_skey[8],
                                                    int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_sign_r || NULL==pa_sign_s || NULL==pa_msg || 
      NULL==pa_sign_rp || NULL==pa_inv_eph_skey || NULL==pa_reg_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }

   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      int8u* psign_r = pa_sign_r[buf_no];
      int8u* psign_s = pa_sign_s[buf_no];
      const int8u* pmsg = pa_msg[buf_no];
      const BIGNUM* psign_pr = pa_sign_rp[buf_no];
      const BIGNUM* pinv_eph_key = pa_inv_eph_skey[buf_no];
      const BIGNUM* preg_key = pa_reg_skey[buf_no];
      if(NULL==psign_r || NULL==psign_s || NULL==pmsg ||
         NULL==psign_pr || NULL==pinv_eph_key || NULL==preg_key) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }
   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   __ALIGN64 U64 inv_eph[P384_LEN52];
   __ALIGN64 U64 reg_skey[P384_LEN52];
   __ALIGN64 U64 sign_r[P384_LEN52];
   __ALIGN64 U64 sign_s[P384_LEN52];

   /* convert inv_eph, reg_skey and sign_r to mb format */
   ifma_BN_to_mb8((int64u (*)[])inv_eph, pa_inv_eph_skey, P384_BITSIZE);
   ifma_BN_to_mb8((int64u (*)[])reg_skey, pa_reg_skey, P384_BITSIZE);
   ifma_BN_to_mb8((int64u (*)[])sign_r, pa_sign_rp, P384_BITSIZE);

   /* compute s- signature component: s = (inv_eph) * (msg + prv_skey*sign_r) mod n384 */
   nistp384_ecdsa_sign_s_mb8(sign_s, pa_msg, sign_r, inv_eph, reg_skey, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[])inv_eph, sizeof(inv_eph)/sizeof(U64));
   /* clear copy of the regular secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[])reg_skey, sizeof(reg_skey)/sizeof(U64));

   /* convert sign_r and sing_s to strings */
   ifma_mb8_to_HexStr8(pa_sign_r, (const int64u(*)[8])sign_r, P384_BITSIZE);
   ifma_mb8_to_HexStr8(pa_sign_s, (const int64u(*)[8])sign_s, P384_BITSIZE);

   /* check if sign_r!=0 and sign_s!=0 */
   int8u stt_mask_r = MB_FUNC_NAME(is_zero_FE384_)(sign_r);
   int8u stt_mask_s = MB_FUNC_NAME(is_zero_FE384_)(sign_s);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_r, MBX_STATUS_LOW_ORDER_ERR);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_s, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

DLL_PUBLIC
mbx_status mbx_nistp384_ecdsa_sign_ssl_mb8(int8u* pa_sign_r[8],
                                           int8u* pa_sign_s[8],
                                     const int8u* const pa_msg[8],
                                    const BIGNUM* const pa_eph_skey[8],
                                    const BIGNUM* const pa_reg_skey[8],
                                           int8u* pBuffer)
{
   mbx_status status = 0;
   int buf_no;

   /* test input pointers */
   if(NULL==pa_sign_r || NULL==pa_sign_s || NULL==pa_msg || NULL==pa_eph_skey || NULL==pa_reg_skey) {
      status = MBX_SET_STS_ALL(MBX_STATUS_NULL_PARAM_ERR);
      return status;
   }
   /* check data pointers */
   for(buf_no=0; buf_no<8; buf_no++) {
      int8u* psign_r = pa_sign_r[buf_no];
      int8u* psign_s = pa_sign_s[buf_no];
      const int8u* pmsg = pa_msg[buf_no];
      const BIGNUM* peph_key = pa_eph_skey[buf_no];
      const BIGNUM* preg_key = pa_reg_skey[buf_no];
      /* if any of pointer NULL set error status */
      if(NULL==psign_r || NULL==psign_s || NULL==pmsg || NULL==peph_key || NULL==preg_key) {
         status = MBX_SET_STS(status, buf_no, MBX_STATUS_NULL_PARAM_ERR);
      }
   }
   if(!MBX_IS_ANY_OK_STS(status) )
      return status;

   __ALIGN64 U64 inv_eph_key[P384_LEN52];
   __ALIGN64 U64 reg_key[P384_LEN52];
   __ALIGN64 U64 sign_r[P384_LEN52];
   __ALIGN64 U64 sign_s[P384_LEN52];
   __ALIGN64 U64 scalar[P384_LEN64+1];

   /* convert ephemeral keys into FE and compute inversion */
   ifma_BN_to_mb8((int64u (*)[])inv_eph_key, pa_eph_skey, P384_BITSIZE);
   nistp384_ecdsa_inv_keys_mb8(inv_eph_key, inv_eph_key, pBuffer);

   /* convert epphemeral keys into sclar and compute sign_r */
   ifma_BN_transpose_copy((int64u (*)[])scalar, pa_eph_skey, P384_BITSIZE);
   scalar[P384_LEN64] = get_zero64();
   nistp384_ecdsa_sign_r_mb8(sign_r, scalar, pBuffer);

   /* convert reg_skey and compute s-component */
   ifma_BN_to_mb8((int64u (*)[])reg_key, pa_reg_skey, P384_BITSIZE);
   nistp384_ecdsa_sign_s_mb8(sign_s, pa_msg, sign_r, inv_eph_key, reg_key, pBuffer);

   /* clear copy of the ephemeral secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[])inv_eph_key, sizeof(inv_eph_key)/sizeof(U64));
   MB_FUNC_NAME(zero_)((int64u (*)[])scalar, sizeof(scalar)/sizeof(U64));

   /* clear copy of the regular secret keys */
   MB_FUNC_NAME(zero_)((int64u (*)[])reg_key, sizeof(reg_key)/sizeof(U64));

   /* convert singnature components to strings */
   ifma_mb8_to_HexStr8(pa_sign_r, (const int64u(*)[8])sign_r, P384_BITSIZE);
   ifma_mb8_to_HexStr8(pa_sign_s, (const int64u(*)[8])sign_s, P384_BITSIZE);

   /* check if sign_r!=0 and sign_s!=0 */
   int8u stt_mask_r = MB_FUNC_NAME(is_zero_FE384_)(sign_r);
   int8u stt_mask_s = MB_FUNC_NAME(is_zero_FE384_)(sign_s);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_r, MBX_STATUS_LOW_ORDER_ERR);
   status |= MBX_SET_STS_BY_MASK(status, stt_mask_s, MBX_STATUS_LOW_ORDER_ERR);
   return status;
}

#endif // BN_OPENSSL_DISABLE
