# The MB (Meta-Build wrapper) documentation

* The [User Guide](user_guide.md)
* The [Design Spec](design_spec.md)
