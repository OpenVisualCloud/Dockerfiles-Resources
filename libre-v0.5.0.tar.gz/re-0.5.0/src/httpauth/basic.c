/**
 * @file basic.c HTTP Basic authentication
 *
 * Copyright (C) 2010 Creytiv.com
 */
#include <re_types.h>
#include <re_mbuf.h>
#include <re_md5.h>
#include <re_fmt.h>
#include <re_httpauth.h>


/* todo */
