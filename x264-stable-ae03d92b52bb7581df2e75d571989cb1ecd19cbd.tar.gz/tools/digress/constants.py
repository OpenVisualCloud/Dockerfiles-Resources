"""
All of Digress's constants.
"""

TEST_PASS = 0
TEST_FAIL = 1
TEST_DISABLED = 2
TEST_SKIPPED = 3

CASE_PASS = 0
CASE_FAIL = 1

FIXTURE_PASS = 0
FIXTURE_FAIL = 1
