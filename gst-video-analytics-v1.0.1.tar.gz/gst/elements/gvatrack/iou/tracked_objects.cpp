/*******************************************************************************
 * Copyright (C) 2018-2020 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#include "tracked_objects.h"

using namespace iou;

const int TrackedObject::UNKNOWN_LABEL_IDX = -1;
