/*******************************************************************************
 * Copyright (C) 2018-2020 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#include "gstgvametaconvert.h"

#include <gst/base/gstbasetransform.h>
#include <gst/gst.h>
#include <gst/video/video.h>

#include "config.h"
#include "converters.h"
#include "gva_caps.h"
#include "gva_json_meta.h"

#define UNUSED(x) (void)(x)

#define ELEMENT_LONG_NAME "Metadata converter"
#define ELEMENT_DESCRIPTION "Metadata converter"

GST_DEBUG_CATEGORY_STATIC(gst_gva_meta_convert_debug_category);
#define GST_CAT_DEFAULT gst_gva_meta_convert_debug_category
/* prototypes */

static void gst_gva_meta_convert_set_property(GObject *object, guint property_id, const GValue *value,
                                              GParamSpec *pspec);
static void gst_gva_meta_convert_get_property(GObject *object, guint property_id, GValue *value, GParamSpec *pspec);
static void gst_gva_meta_convert_dispose(GObject *object);
static void gst_gva_meta_convert_finalize(GObject *object);

static gboolean gst_gva_meta_convert_set_caps(GstBaseTransform *trans, GstCaps *incaps, GstCaps *outcaps);
static gboolean gst_gva_meta_convert_start(GstBaseTransform *trans);
static gboolean gst_gva_meta_convert_stop(GstBaseTransform *trans);
static gboolean gst_gva_meta_convert_sink_event(GstBaseTransform *trans, GstEvent *event);
static GstFlowReturn gst_gva_meta_convert_transform_ip(GstBaseTransform *trans, GstBuffer *buf);
static void gst_gva_meta_convert_cleanup(GstGvaMetaConvert *gvametaconvert);
static void gst_gva_meta_convert_reset(GstGvaMetaConvert *gvametaconvert);
static GstStateChangeReturn gst_gva_meta_convert_change_state(GstElement *element, GstStateChange transition);

enum {
    SIGNAL_HANDOFF,
    /* FILL ME */
    LAST_SIGNAL
};
static guint gst_interpret_signals[LAST_SIGNAL] = {0};

#define DEFAULT_FORMAT GST_GVA_METACONVERT_JSON
#define DEFAULT_SIGNAL_HANDOFFS FALSE
#define DEFAULT_ADD_TENSOR_DATA FALSE
#define DEFAULT_SOURCE NULL
#define DEFAULT_TAGS NULL
#define DEFAULT_ADD_EMPTY_DETECTION_RESULTS FALSE

enum {
    PROP_0,
    PROP_FORMAT,
    PROP_ADD_TENSOR_DATA,
    PROP_SIGNAL_HANDOFFS,
    PROP_SOURCE,
    PROP_TAGS,
    PROP_ADD_EMPTY_DETECTION_RESULTS,
};

/* class initialization */

G_DEFINE_TYPE_WITH_CODE(GstGvaMetaConvert, gst_gva_meta_convert, GST_TYPE_BASE_TRANSFORM,
                        GST_DEBUG_CATEGORY_INIT(gst_gva_meta_convert_debug_category, "gvametaconvert", 0,
                                                "debug category for gvametaconvert element"));

GType gst_gva_metaconvert_get_format(void) {
    static GType gva_metaconvert_format_type = 0;
    static const GEnumValue format_types[] = {
        {GST_GVA_METACONVERT_JSON, "Conversion to GstGVAJSONMeta", "json"},
        {GST_GVA_METACONVERT_DUMP_DETECTION, "Dump detection to GST debug log", "dump-detection"},
        {0, NULL, NULL}};

    if (!gva_metaconvert_format_type) {
        gva_metaconvert_format_type = g_enum_register_static("GstGVAMetaconvertFormatType", format_types);
    }
    return gva_metaconvert_format_type;
}

static void gst_gva_metaconvert_set_format(GstGvaMetaConvert *gvametaconvert, GstGVAMetaconvertFormatType format_type) {
    GST_DEBUG_OBJECT(gvametaconvert, "setting format to %d", format_type);

    GHashTable *converters = get_converters();
    convert_function_type convert_function = g_hash_table_lookup(converters, GINT_TO_POINTER(format_type));

    if (convert_function) {
        gvametaconvert->format = format_type;
        gvametaconvert->convert_function = convert_function;
    } else
        g_assert_not_reached();

    g_hash_table_destroy(converters);
}

static void gst_gva_meta_convert_class_init(GstGvaMetaConvertClass *klass) {
    GObjectClass *gobject_class = G_OBJECT_CLASS(klass);
    GstBaseTransformClass *base_transform_class = GST_BASE_TRANSFORM_CLASS(klass);
    GstElementClass *element_class = GST_ELEMENT_CLASS(klass);

    /* Setting up pads and setting metadata should be moved to
       base_class_init if you intend to subclass this class. */
    gst_element_class_add_pad_template(
        GST_ELEMENT_CLASS(klass),
        gst_pad_template_new("src", GST_PAD_SRC, GST_PAD_ALWAYS, gst_caps_from_string(GVA_CAPS)));
    gst_element_class_add_pad_template(
        GST_ELEMENT_CLASS(klass),
        gst_pad_template_new("sink", GST_PAD_SINK, GST_PAD_ALWAYS, gst_caps_from_string(GVA_CAPS)));

    gst_element_class_set_static_metadata(GST_ELEMENT_CLASS(klass), ELEMENT_LONG_NAME, "Video", ELEMENT_DESCRIPTION,
                                          "Intel Corporation");

    gobject_class->set_property = gst_gva_meta_convert_set_property;
    gobject_class->get_property = gst_gva_meta_convert_get_property;
    gobject_class->dispose = gst_gva_meta_convert_dispose;
    gobject_class->finalize = gst_gva_meta_convert_finalize;
    base_transform_class->set_caps = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_set_caps);
    base_transform_class->start = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_start);
    base_transform_class->stop = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_stop);
    base_transform_class->sink_event = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_sink_event);
    base_transform_class->transform_ip = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_transform_ip);
    element_class->change_state = GST_DEBUG_FUNCPTR(gst_gva_meta_convert_change_state);

    g_object_class_install_property(gobject_class, PROP_FORMAT,
                                    g_param_spec_enum("format", "Format", "Output format for conversion. Enum: (1) \
                                                      json GstGVAJSONMeta representing inference results. For \
                                                      details on the schema please see the user guide.",
                                                      GST_TYPE_GVA_METACONVERT_FORMAT, DEFAULT_FORMAT,
                                                      G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(gobject_class, PROP_ADD_TENSOR_DATA,
                                    g_param_spec_boolean("add-tensor-data", "Add Tensor Data", "Add raw tensor data in \
                                                      addition to detection and classification labels.",
                                                         DEFAULT_ADD_TENSOR_DATA,
                                                         G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(
        gobject_class, PROP_SIGNAL_HANDOFFS,
        g_param_spec_boolean("signal-handoffs", "Signal handoffs", "Send signal before pushing the buffer",
                             DEFAULT_SIGNAL_HANDOFFS, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(gobject_class, PROP_SOURCE,
                                    g_param_spec_string("source", "Source URI", "User supplied URI identifying the \
                                    media source associated with the inference results",
                                                        DEFAULT_SOURCE, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(gobject_class, PROP_TAGS,
                                    g_param_spec_string("tags", "Custom tags",
                                                        "User supplied JSON object of additional properties added to \
                                                        each frame's inference results",
                                                        DEFAULT_TAGS, G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    g_object_class_install_property(gobject_class, PROP_ADD_EMPTY_DETECTION_RESULTS,
                                    g_param_spec_boolean("add-empty-results", "include metas with no \
                                                         detections",
                                                         "Add metadata when inference is run but no \
                                                         results meet the detection threshold",
                                                         DEFAULT_ADD_EMPTY_DETECTION_RESULTS,
                                                         G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS));

    gst_interpret_signals[SIGNAL_HANDOFF] = g_signal_new(
        "handoff", G_TYPE_FROM_CLASS(klass), G_SIGNAL_RUN_LAST, G_STRUCT_OFFSET(GstGvaMetaConvertClass, handoff), NULL,
        NULL, g_cclosure_marshal_generic, G_TYPE_NONE, 1, GST_TYPE_BUFFER | G_SIGNAL_TYPE_STATIC_SCOPE);
}

static void gst_gva_meta_convert_cleanup(GstGvaMetaConvert *gvametaconvert) {
    if (gvametaconvert == NULL)
        return;

    GST_DEBUG_OBJECT(gvametaconvert, "gst_gva_meta_convert_cleanup");

    g_free(gvametaconvert->source);
    gvametaconvert->source = NULL;
    g_free(gvametaconvert->tags);
    gvametaconvert->tags = NULL;
    if (gvametaconvert->info) {
        gst_video_info_free(gvametaconvert->info);
        gvametaconvert->info = NULL;
    }
}

static void gst_gva_meta_convert_reset(GstGvaMetaConvert *gvametaconvert) {
    GST_DEBUG_OBJECT(gvametaconvert, "gst_gva_meta_convert_reset");

    if (gvametaconvert == NULL)
        return;

    gst_gva_meta_convert_cleanup(gvametaconvert);

    gvametaconvert->add_tensor_data = DEFAULT_ADD_TENSOR_DATA;
    gvametaconvert->source = g_strdup(DEFAULT_SOURCE);
    gvametaconvert->tags = g_strdup(DEFAULT_TAGS);
    gvametaconvert->add_empty_detection_results = DEFAULT_ADD_EMPTY_DETECTION_RESULTS;
    gvametaconvert->signal_handoffs = DEFAULT_SIGNAL_HANDOFFS;
    gst_gva_metaconvert_set_format(gvametaconvert, DEFAULT_FORMAT);
    gvametaconvert->info = NULL;
}

static GstStateChangeReturn gst_gva_meta_convert_change_state(GstElement *element, GstStateChange transition) {
    GstStateChangeReturn ret;
    GstGvaMetaConvert *gvametaconvert;

    gvametaconvert = GST_GVA_META_CONVERT(element);
    GST_DEBUG_OBJECT(gvametaconvert, "gst_gva_meta_convert_change_state");

    ret = GST_ELEMENT_CLASS(gst_gva_meta_convert_parent_class)->change_state(element, transition);

    switch (transition) {
    case GST_STATE_CHANGE_READY_TO_NULL: {
        gst_gva_meta_convert_reset(gvametaconvert);
        break;
    }
    default:
        break;
    }

    return ret;
}

static void gst_gva_meta_convert_init(GstGvaMetaConvert *gvametaconvert) {
    gst_gva_meta_convert_reset(gvametaconvert);
}

void gst_gva_meta_convert_set_property(GObject *object, guint property_id, const GValue *value, GParamSpec *pspec) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(object);

    GST_DEBUG_OBJECT(gvametaconvert, "set_property");

    switch (property_id) {
    case PROP_FORMAT:
        gst_gva_metaconvert_set_format(gvametaconvert, g_value_get_enum(value));
        break;
    case PROP_ADD_TENSOR_DATA:
        gvametaconvert->add_tensor_data = g_value_get_boolean(value);
        break;
    case PROP_SOURCE:
        g_free(gvametaconvert->source);
        gvametaconvert->source = g_value_dup_string(value);
        break;
    case PROP_TAGS:
        g_free(gvametaconvert->tags);
        gvametaconvert->tags = g_value_dup_string(value);
        break;
    case PROP_ADD_EMPTY_DETECTION_RESULTS:
        gvametaconvert->add_empty_detection_results = g_value_get_boolean(value);
        break;
    case PROP_SIGNAL_HANDOFFS:
        gvametaconvert->signal_handoffs = g_value_get_boolean(value);
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID(object, property_id, pspec);
        break;
    }
}

void gst_gva_meta_convert_get_property(GObject *object, guint property_id, GValue *value, GParamSpec *pspec) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(object);

    GST_DEBUG_OBJECT(gvametaconvert, "get_property");

    switch (property_id) {
    case PROP_FORMAT:
        g_value_set_enum(value, gvametaconvert->format);
        break;
    case PROP_ADD_TENSOR_DATA:
        g_value_set_boolean(value, gvametaconvert->add_tensor_data);
        break;
    case PROP_SOURCE:
        g_value_set_string(value, gvametaconvert->source);
        break;
    case PROP_TAGS:
        g_value_set_string(value, gvametaconvert->tags);
        break;
    case PROP_ADD_EMPTY_DETECTION_RESULTS:
        g_value_set_boolean(value, gvametaconvert->add_empty_detection_results);
        break;
    case PROP_SIGNAL_HANDOFFS:
        g_value_set_boolean(value, gvametaconvert->signal_handoffs);
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID(object, property_id, pspec);
        break;
    }
}

void gst_gva_meta_convert_dispose(GObject *object) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(object);

    GST_DEBUG_OBJECT(gvametaconvert, "dispose");

    /* clean up as possible.  may be called multiple times */

    G_OBJECT_CLASS(gst_gva_meta_convert_parent_class)->dispose(object);
}

void gst_gva_meta_convert_finalize(GObject *object) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(object);

    GST_DEBUG_OBJECT(gvametaconvert, "finalize");

    /* clean up object here */

    gst_gva_meta_convert_cleanup(gvametaconvert);

    G_OBJECT_CLASS(gst_gva_meta_convert_parent_class)->finalize(object);
}

static gboolean gst_gva_meta_convert_set_caps(GstBaseTransform *trans, GstCaps *incaps, GstCaps *outcaps) {
    UNUSED(outcaps);

    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(trans);
    GST_DEBUG_OBJECT(gvametaconvert, "set_caps");
    if (!gvametaconvert->info) {
        gvametaconvert->info = gst_video_info_new();
    }
    gst_video_info_from_caps(gvametaconvert->info, incaps);
    return TRUE;
}

/* states */
static gboolean gst_gva_meta_convert_start(GstBaseTransform *trans) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(trans);

    GST_DEBUG_OBJECT(gvametaconvert, "start");

    return TRUE;
}

static gboolean gst_gva_meta_convert_stop(GstBaseTransform *trans) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(trans);

    GST_DEBUG_OBJECT(gvametaconvert, "stop");

    return TRUE;
}

/* sink and src pad event handlers */
static gboolean gst_gva_meta_convert_sink_event(GstBaseTransform *trans, GstEvent *event) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(trans);

    GST_DEBUG_OBJECT(gvametaconvert, "sink_event");

    return GST_BASE_TRANSFORM_CLASS(gst_gva_meta_convert_parent_class)->sink_event(trans, event);
}

static GstFlowReturn gst_gva_meta_convert_transform_ip(GstBaseTransform *trans, GstBuffer *buf) {
    GstGvaMetaConvert *gvametaconvert = GST_GVA_META_CONVERT(trans);

    if (gvametaconvert->signal_handoffs) {
        g_signal_emit(gvametaconvert, gst_interpret_signals[SIGNAL_HANDOFF], 0, buf);
    } else if (gvametaconvert->convert_function) {
        gvametaconvert->convert_function(gvametaconvert, buf);
    }

    return GST_FLOW_OK;
}
