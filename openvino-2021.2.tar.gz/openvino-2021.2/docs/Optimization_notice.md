# Optimization Notice {#openvino_docs_Optimization_notice}

![Optimization_notice](img/opt-notice-en_080411.gif)