// Copyright (C) 2020 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include "functional_test_utils/plugin_config.hpp"

void PreparePluginConfiguration(LayerTestsUtils::LayerTestsCommon* test) {
}
