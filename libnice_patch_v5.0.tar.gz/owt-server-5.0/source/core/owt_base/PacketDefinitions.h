/*
 * Add proxy in rtcConn wrapper layer (or create a wrapper for libwebrtc.a)
 */

 class Packet