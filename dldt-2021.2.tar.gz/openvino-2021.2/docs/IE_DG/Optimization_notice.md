# Optimization Notice {#openvino_docs_IE_DG_Optimization_notice}

![Optimization_notice](img/opt-notice-en_080411.gif)