# gstreamer-vaapi-patch

LGPL-licensed patch for gstreamer-vaapi plugins to allow other MIT-licences plugins to extract VASurfaceID and VADisplay from GstBuffer created by VAAPI plugins

