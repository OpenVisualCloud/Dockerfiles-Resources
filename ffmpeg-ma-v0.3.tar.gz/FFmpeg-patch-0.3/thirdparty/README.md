# Dependent thirdparty patches

## 0001-Add-inference-engine-C-API.patch
## 0002-Change-to-match-image-with-separate-planes.patch
## 0003-Refine-IE-C-API.patch
## 0004-Fix-code-style-and-symbols-visibility-for-2019R1.patch
- Patches to add C API for [dldt](https://github.com/opencv/dldt)

