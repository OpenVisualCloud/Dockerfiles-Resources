Instructions to create your own Firefox Screensharing Extension:

1. Modify bootstrap.js file, updating the variable domainsUsed with your own domains.

2. Modify install.rdf with your own extension information

3. Choose your icon (48x48) and name it icon.png 

4. Run createExtension.sh script to create your .xpi containing the three files.

5. Install the .xpi file in Firefox

6. Enjoy Firefox Screensharing with Licode!