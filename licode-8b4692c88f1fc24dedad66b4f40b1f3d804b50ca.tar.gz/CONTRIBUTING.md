# Contributing to Licode

Thank you for considering contributing to Licode!
We keep an up-to-date guide in the [Licode web](http://lynckia.com/licode/contribute.html).
