# Contact information

For general discussion and questions, it is strongly recommended that
you use the [mailing
list](https://groups.google.com/forum/#!forum/mesonbuild).

If you find bugs, please file them in the [issue
tracker](https://github.com/jpakkane/meson/issues).

The maintainer of Meson is Jussi Pakkanen. You should usually not
contact him privately but rather use the channels listed
above. However if such a need arises, he can be reached at gmail where
his username is `jpakkane` (that is not a typo, the last letter is
indeed *e*).
