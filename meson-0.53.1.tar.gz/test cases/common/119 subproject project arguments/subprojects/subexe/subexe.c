#ifdef PROJECT_OPTION
#error
#endif

#ifdef PROJECT_OPTION_1
#error
#endif

#ifdef PROJECT_OPTION_C_CPP
#error
#endif

#ifndef GLOBAL_ARGUMENT
#error
#endif

#ifndef SUBPROJECT_OPTION
#error
#endif

#ifdef OPTION_CPP
#error
#endif

int main(void) {
    return 0;
}
