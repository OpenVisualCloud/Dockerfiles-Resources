#ifdef PROJECT_OPTION
#error
#endif

#ifdef PROJECT_OPTION_1
#error
#endif

#ifdef GLOBAL_ARGUMENT
#error
#endif

#ifdef SUBPROJECT_OPTION
#error
#endif

#ifndef PROJECT_OPTION_CPP
#error
#endif

#ifndef PROJECT_OPTION_C_CPP
#error
#endif

int main(void) {
    return 0;
}

