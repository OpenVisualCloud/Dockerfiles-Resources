int func2(void) {
    return 42;
}
