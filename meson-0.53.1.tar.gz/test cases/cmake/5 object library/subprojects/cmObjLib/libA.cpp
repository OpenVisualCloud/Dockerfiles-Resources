#include "libA.hpp"

std::string getLibStr(void) {
  return "Hello World";
}
