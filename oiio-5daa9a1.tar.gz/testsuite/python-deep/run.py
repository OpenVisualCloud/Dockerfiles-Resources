#!/usr/bin/env python 

command += "python src/test_deep.py > out.txt"

