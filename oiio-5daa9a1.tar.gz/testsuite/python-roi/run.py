#!/usr/bin/env python 

command += "python src/test_roi.py > out.txt"

