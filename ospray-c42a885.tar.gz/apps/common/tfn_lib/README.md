# tfn\_lib

Utility and standalone library for saving/loading transfer functions across the different viewers.
Ideally will also have a standalone app for converting a ParaView exported transfer function to our
internal binary format.

