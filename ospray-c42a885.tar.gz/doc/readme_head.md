OSPRay
======

This is release v<OSPRAY_VERSION> of OSPRay. For changes and new features see the
[changelog](CHANGELOG.md). Visit http://www.ospray.org for more information.

