---
short-description:  GStreamer Bad Plugins API reference.
...

# GStreamer Bad Plugins
