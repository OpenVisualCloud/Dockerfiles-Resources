# Video helpers and baseclasses

> NOTE: This library API is considered *unstable*
