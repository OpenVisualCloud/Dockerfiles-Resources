# Base classes from -bad

> NOTE: This library API is considered *unstable*
