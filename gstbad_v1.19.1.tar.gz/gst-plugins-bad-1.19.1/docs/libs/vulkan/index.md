# Vulkan Library

This library should be linked to by getting cflags and libs from
gstreamer-vulkan-{{ gst_api_version.md }}

> NOTE: This library API is considered *unstable*
