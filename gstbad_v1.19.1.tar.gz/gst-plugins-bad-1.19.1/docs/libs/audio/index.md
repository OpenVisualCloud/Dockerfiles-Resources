# Bad Audio library

This library should be linked to by getting cflags and libs from
gstreamer-bad-audio{{ gst_api_version.md }}.pc

> NOTE: This library API is considered *unstable*
