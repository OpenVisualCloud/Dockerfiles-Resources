---
short-description: A library that contains a bin to insertally link filter-like elements.
...

# GstInsertBin

> NOTE: This library API is considered *unstable*
