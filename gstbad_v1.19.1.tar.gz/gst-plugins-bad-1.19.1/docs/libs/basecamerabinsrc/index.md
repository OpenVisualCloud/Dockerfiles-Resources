# BaseCamerabinSrc Library

This library should be linked to by getting cflags and libs from
gstreamer-plugins-bad-{{ gst_api_version.md }}.pc and adding
-lgstbasecamerabinsrc-{{ gst_api_version.md }} to the library flags.

> NOTE: This library API is considered *unstable*
