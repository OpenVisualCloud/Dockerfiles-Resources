#!/bin/sh
# Script modified from upstream source for Debian packaging since packaging
# won't include .git repository.
echo '#define X264_VERSION " r2917 0a84d98"'
echo '#define X264_POINTVER "0.155.2917 0a84d98"'
