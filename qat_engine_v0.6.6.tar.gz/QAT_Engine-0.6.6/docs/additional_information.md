## Additional Information

* [Intel&reg; QuickAssist Technology Driver][1]
* [White Paper: Intel&reg; QuickAssist Technology and OpenSSL-1.1.0:Performance][2]

Additional Information on integrating the Intel&reg QAT OpenSSL\* Engine with NGINX\*
including an asynchronous fork of NGINX\* can be found at the following Github\*
repository:

* [Intel&reg; QuickAssist Technology (QAT) Async Mode NGINX\*][3]

[1]:https://01.org/intel-quickassist-technology
[2]:https://01.org/sites/default/files/downloads/intelr-quickassist-technology/337003-001-intelquickassisttechnologyandopenssl-110.pdf
[3]:https://github.com/intel/asynch_mode_nginx
