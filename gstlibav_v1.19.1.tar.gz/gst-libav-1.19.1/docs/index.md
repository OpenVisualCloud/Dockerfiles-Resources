---
short-description:  GStreamer plugins from gst-ffmpeg
...

# FFMPEG plugin
