# Base and Utility classes

`gstreamer-base` provides some base classes to be extended by elements and utility classes that are most useful for plugin developers.
