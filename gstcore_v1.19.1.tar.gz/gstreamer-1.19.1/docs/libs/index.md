# GStreamer core libraries API
