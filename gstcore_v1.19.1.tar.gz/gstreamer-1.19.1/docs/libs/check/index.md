# Check Unit Testing

`gstreamer-check` provides functionality for writing unit tests that use the check framework.
