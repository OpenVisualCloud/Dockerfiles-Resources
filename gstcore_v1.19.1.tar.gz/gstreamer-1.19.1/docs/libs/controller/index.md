# Dynamic Parameter Control

`gstreamer-controller` provides functionality to animate element properties over time.
