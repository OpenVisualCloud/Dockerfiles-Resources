---
short-description: GStreamer plugin from GStreamer core
...

# Core Plugin
