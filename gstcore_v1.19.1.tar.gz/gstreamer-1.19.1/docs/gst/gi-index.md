# Core Library

libgstreamer-{{ gst_api_version.md }}.so provides all the core GStreamer
services, including initialization, plugin management and types, as well
as the object hierarchy that defines elements and bins, along with some
more specialized elements.
