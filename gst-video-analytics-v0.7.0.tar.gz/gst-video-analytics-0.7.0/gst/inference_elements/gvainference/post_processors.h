/*******************************************************************************
 * Copyright (C) 2018-2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#pragma once

#include <processor_types.h>

#ifdef __cplusplus
extern "C" {
#endif

extern PostProcFunction EXTRACT_INFERENCE_RESULTS;

#ifdef __cplusplus
}
#endif