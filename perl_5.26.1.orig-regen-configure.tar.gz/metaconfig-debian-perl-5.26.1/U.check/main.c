#include "config.h"
int
main(argc, argv)
  int argc;
  char **argv;
{
  SCHED_YIELD;
}
