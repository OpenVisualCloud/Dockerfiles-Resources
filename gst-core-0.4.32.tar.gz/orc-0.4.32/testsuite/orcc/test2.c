
#include <stdio.h>

int
main (int argc, char *argv[])
{

  /* This is mostly just to test that compilation works */

  return 0;
}

